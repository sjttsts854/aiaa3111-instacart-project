# Reproducing the experiments

## Portable inspection

Start with the top-level `verify_package.py` and `evidence_app.py`. They do not need raw data or model fitting. The verifier independently recomputes seed-42 case Recall@10 using full repeat targets, checks candidate budgets, empty targets and all file hashes. Its PASS is a package-level check, not a rerun of the original raw-source audit.

## Unit tests

From `code/`, create an environment and install `requirements-study-lock.txt`. Python 3.13.5 was used for the recorded run. Other supported Python/platform combinations may differ numerically; do not promise byte-identical model artifacts or confidence endpoints.

```powershell
python -m pip install -r requirements-study-lock.txt
python -m pytest tests study3_tests study4_tests followup_tests -q
```

The original workspace passed 108 research tests. These are implementation checks, not independent evidence of scientific generalization.

## Recreate the main Study 4 and its posthoc diagnostics

Run the following commands in a **fresh copy of `code/`**, after placing the six verified source CSVs in `archive/`. The initial three prepare stages reconstruct the previously used user cohorts that Study 4 excludes. They do not require refitting the earlier methods, although `study3.prepare` also builds its fixed rule features. Preparation and fitting read millions of rows, so allow substantial memory and disk space. No runtime budget is promised.

```powershell
python run.py prepare
python -m research.run prepare
python -m study3.prepare
python -m study4.prepare
python -m study4.run develop
python -m study4.run freeze
python -m study4.run confirm
python -m study4.run audit
python -m study4.run report
python -m study4_followup.run analyze
python -m study4_followup.run audit
python -m study4_followup.run report
```

The fixed seeds reproduce the original cohort design. Rerunning these already-seen users is a reproduction, not a new independent confirmation. Development selects M only using validation; confirmation does not reselect it. Followup analysis remains posthoc even when rerun from this source.

Files and models are hashed by each newly created run before its own confirmation. Original `provenance/*freeze.json` records refer to the original complete workspace, whose caches and binaries are not bundled. Do not copy those manifests into a new run or expect their hashes to match refitted model serialization. Do not edit frozen sources after a new freeze. Completed-stage protection is intentional; start another clean reproduction folder instead of deleting guards to retune known confirmation users.

## Optional earlier evidence

Study 2 requires its prepared data above, then `python -m research.run features`, `develop`, `freeze`, `confirm`, `audit`, `report`. Its freeze records a Git commit, so initialize a local Git repository and commit the source before that freeze if the reproduction folder is not already a repository. Use the team's own Git identity. Study 3 then uses `python -m study3.run develop`, `freeze`, `confirm`, `audit`, `report`. The TIFU adaptation and its author-code semantics are documented under `study3/`; the adaptation is not a reproduction of the original paper's whole-basket benchmark scores.

The initial 10,000-user exploratory loop is retained as source (`run.py`, `configs/`, `scripts/autoresearch_loop.py`). It is background to the final question, not required to refit for the Study 4 result. The lean package's top-level English viewer is the supported presentation entry point; the original legacy app was not included because it depends on the large older model caches.

## What was validated for this handoff

- Original studies and posthoc diagnostics have saved independent audit PASS records.
- Original frozen experiment files were not altered for this handoff.
- The packaged viewer uses genuine Study 4 seed-42 outputs, not the legacy Study 2 cases.
- Package metric and integrity checks, portable UI cases and the copied research test suite are checked separately during closeout.
- No clean-room refitting of millions of rows is claimed merely because documentation and source are included.
