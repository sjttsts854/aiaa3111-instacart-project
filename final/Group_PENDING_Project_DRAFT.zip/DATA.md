# Dataset and source identity

Download the Instacart mirror from https://www.kaggle.com/datasets/yasserh/instacart-online-grocery-basket-analysis-dataset and extract the following six files into `code/archive/`. You may need a Kaggle account. Review the source terms before redistribution. This package does not redistribute the six raw source files.

The mirror contains the original competition data, including labeled terminal baskets and unlabeled competition test baskets. Research targets use labeled users only. CSV identity is established by the hashes below; the files alone do not establish the mirror webpage revision number.

| File | Bytes | SHA256 |
| --- | ---: | --- |
| aisles.csv | 2603 | 2c5f4677761907d3a3ca01edd2d2abe67c147cc60e4905e68736d5f9f3046067 |
| departments.csv | 270 | e6829cea3da95ec22eeb4e0294094a68b929f3bcfda48fdd7d1e33403110fc43 |
| orders.csv | 108968645 | 92a60ced67ac33bd82271f66ff9675374f69482d17a0e1442ba42caa8b3bff89 |
| order_products__prior.csv | 577550706 | 27b59dc9cf0d485f55e64e0bc9c5d6fb077ae167f8dfeab9246a03b5b0186359 |
| order_products__train.csv | 24680147 | d27c4034883051c85e37c2cb0379fecbbeccad932970e171461aa99f18f75aea |
| products.csv | 2166953 | abc61fdd748003d280ae49cc5d71b65380805ab1ca55dba96fd9a49295ea78b9 |

Source totals: 206,209 users, 3,421,083 orders and 49,688 products; 131,209 users have labeled terminal orders. There are no prices or absolute timestamps; intervals are capped at 30 days. The task predicts next-order repeats within each user's complete observed historical catalog, not forgotten needs or all first-purchase products.

`data_demo/` contains compact derived records for the 8,000 Study 4 confirmation users: product history counts/recency, terminal products with historical membership, frozen seed-42 recommendations, and product names. These public-dataset user IDs are anonymous. This subset is sufficient for inspecting frozen examples, not for retraining.
