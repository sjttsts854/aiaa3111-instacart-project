# Research source

Run commands from this directory. See ../REPRODUCE.md for the documented command sequence and ../DATA.md for inputs. Source modules and historical implementation notes are preserved unchanged, including original comments. The new presentation materials and portable viewer are English.
